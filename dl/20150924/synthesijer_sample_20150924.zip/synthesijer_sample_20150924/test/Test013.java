public class Test013{
	private final Test013_A obj0 = new Test013_B();
	private final Test013_A obj1 = new Test013_C();
	
	public void test(){
		int a = obj0.hoge();
		int b = obj1.hoge();
	}
}
