public abstract class Test013_A{
	abstract public int hoge();
}
