These sample codes is from http://www.kmonos.net/alang/etc/brainfuck.php
