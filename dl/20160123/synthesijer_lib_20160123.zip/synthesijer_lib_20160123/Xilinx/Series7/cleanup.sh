rm -f *.tcl
rm -f *.v*
rm -f *.asy *.gise *.ngc *.sym *.txt
rm -f coregen.cgc
rm -f coregen.cgp
rm -f coregen.log
rm -rf demo_tb
rm -rf f*_ip
rm -rf div*_ip
rm -rf tmp
rm -rf xlnx_auto_0_xdb
rm -rf _xmsgs
