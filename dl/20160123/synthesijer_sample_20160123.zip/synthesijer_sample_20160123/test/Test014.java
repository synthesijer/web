public class Test014{

	public int test_ar0(int a){
		return a >> 0;
	}

	public int test_ar1(int a){
		return a >> 1;
	}

	public int test_ar8(int a){
		return a >> 8;
	}

	public int test_ar16(int a){
		return a >> 16;
	}

	public int test_ar24(int a){
		return a >> 24;
	}

	public int test_ar31(int a){
		return a >> 31;
	}

	public int test_ar32(int a){
		return a >> 32;
	}

	public int test_lr0(int a){
		return a >>> 0;
	}

	public int test_lr1(int a){
		return a >>> 1;
	}

	public int test_lr8(int a){
		return a >>> 8;
	}

	public int test_lr16(int a){
		return a >>> 16;
	}

	public int test_lr24(int a){
		return a >>> 24;
	}

	public int test_lr31(int a){
		return a >>> 31;
	}

	public int test_lr32(int a){
		return a >>> 32;
	}
}
