public class Test013_B extends Test013_A{
	public int hoge(){
		return 10;
	}
}
