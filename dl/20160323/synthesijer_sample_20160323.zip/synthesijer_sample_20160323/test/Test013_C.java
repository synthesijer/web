public class Test013_C extends Test013_A{
	public int hoge(){
		return 20;
	}
}
