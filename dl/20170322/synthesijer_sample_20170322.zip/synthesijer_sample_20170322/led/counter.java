
public class counter{

  int counter = 0;
	
  public void up(){
    counter++;
  }

  public void clear(){
    counter = 0;
  }

  public void set(int v){
    counter = v;
  }

}
