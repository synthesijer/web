public class Test012 extends Test010{
	public void run(){
		test();
	}
}
