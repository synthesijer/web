java -cp ../../../bin:../../../../target/synthesijer:. \
  synthesijer.Main \
  ../../../extra-libs/src/synthesijer/lib/axi/SimpleAXIMemIface32RTL.java \
  ../../../extra-libs/src/synthesijer/lib/axi/SimpleAXIMemIface32RTLTest.java \
  TestFrame.java \
  RGBTest.java \
  SinTableRom.java
