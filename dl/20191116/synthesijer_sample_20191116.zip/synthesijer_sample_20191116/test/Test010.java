
public class Test010{

	public void test(){
		int a = 20;
		int b = 30;
		int c = 0;

		c = a & b;
		c = a | b;
		c = a ^ b;
	}

}
