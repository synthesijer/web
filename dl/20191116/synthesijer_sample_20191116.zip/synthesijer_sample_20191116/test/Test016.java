/* this is not available*/
public class Test016{
    
    public byte[] a = new byte[]{1,2,3,4,5,6};

    public byte get(int i){
	return a[i];
    }

    public void set(int i, byte v){
	a[i] = v;
    }

}
